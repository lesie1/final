"""Verify fixed replay reports and package compact evidence, without datasets."""
import sys,math,json,csv,html,zipfile,time
from pathlib import Path
R=Path('/root/autodl-tmp/final_v31_20261028');OUT=R/'rejected_comparison_20261029';BASE=R/'final_test_20261029'
sys.path.insert(0,str(R/'runtime'));sys.dont_write_bytecode=True
from common import read,save,sha,require
from evaluation import classify
import pandas as pd
from compare_rejected_memory import unchanged,compare_tables

def verify_table(folder,report):
 table=pd.read_csv(folder/'devices_test.csv');m=report['metrics'];eligible=table.status.eq('eligible')
 classified=classify(table,m['threshold'])
 for key in ['hit','fp','fn']:require((table[key]==classified[key]).all(),'Threshold classification differs')
 tp=int((eligible&table.hit).sum());fp=int((eligible&table.fp).sum());fn=int((eligible&table.fn).sum())
 require((tp,fp,fn)==(m['TP'],m['FP'],m['FN']),'Counts differ')
 for k,v in dict(f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/(tp+fn) if tp+fn else 0.).items():
  require(abs(v-m[k])<1e-12,'Metric differs: '+k)
 require(int(eligible.sum())==m['eligible_devices'],'Eligible device count differs')
 require(int((eligible&table.positive).sum())==m['eligible_fault_devices'],'Fault count differs')
 return table

def main():
 frozen=read(OUT/'frozen.json');rows=[];summary=dict(independent_blind_test=False,supplementary_comparison=True,threshold_reselected=False,retrained=False,api_calls=0,source_search_preserved=True,tasks={})
 for label,e in frozen['tasks'].items():
  unchanged(label,e);base_report=e['baseline_report'];bm=base_report['metrics'];bt=verify_table(BASE/label,base_report)
  baseline_result=read(Path(e['session'])/'trials/trial_001/attempt_01/result.json');state=read(Path(e['session'])/'state.json')
  basecv=state['trials'][0]['cv']['metrics']['f1']
  def row(t,rep,vm,cv):
   m=rep['metrics'];comp=rep.get('comparison_vs_trial_001',{})
   return dict(task=label,trial=t,validation_f1=vm,cv_f1=cv,test_f1=m['f1'],delta_test_f1=m['f1']-bm['f1'],precision=m['precision'],recall=m['recall'],TP=m['TP'],FP=m['FP'],FN=m['FN'],threshold=m['threshold'],eligible_devices=m['eligible_devices'],eligible_fault_devices=m['eligible_fault_devices'],new_hits=comp.get('new_hits',0),lost_hits=comp.get('lost_hits',0),new_false_alarms=comp.get('new_false_alarms',0),removed_false_alarms=comp.get('removed_false_alarms',0))
  group=[row('trial_001',base_report,baseline_result['metrics']['f1'],basecv)]
  for t in e['candidates']:
   folder=OUT/label/t['trial'];require((folder/'complete.json').exists(),'Replay incomplete: '+label+'/'+t['trial'])
   for n,h in read(folder/'complete.json')['files'].items():require(sha(folder/n)==h,'Replay artifact changed')
   require(sha(Path(t['model']))==t['model_sha256'],'Model changed')
   report=read(folder/'report_test.json');require(report['metrics']['threshold']==t['threshold'],'Threshold changed')
   table=verify_table(folder,report)
   actual=compare_tables(table,bt,t['threshold'],bm['threshold'])
   for k,v in actual.items():require(v==report['comparison_vs_trial_001'][k],'Pair comparison differs: '+k)
   group.append(row(t['trial'],report,t['validation']['f1'],t['cv'].get('f1')))
  summary['tasks'][label]=dict(baseline=group[0],candidates=group[1:],tested_candidates=len(group)-1,improved_candidates=sum(x['delta_test_f1']>0 for x in group[1:]),highest_observed_test_result=max(group,key=lambda x:x['test_f1']),note='Highest observed result is post-hoc descriptive; it is not an independent model selection validation.')
  rows.extend(group)
 historical=OUT/'historical_typeb'
 if (historical/'summary.json').exists():
  for n,h in read(historical/'complete.json')['files'].items():require(sha(historical/n)==h,'Historical comparison artifact changed')
  for trial in ['trial_001','trial_015']:
   folder=historical/('old_'+trial);rep=read(folder/'report_test.json')
   verify_table(folder,dict(metrics=rep['current_full_cohort']))
   for k in ['TP','FP','FN','f1','precision','recall']:
    require(rep['old_eligible_subset'][k]==rep['original_report'][k],'Historical eligible-subset replay differs: '+k)
  summary['historical_typeb']=read(historical/'summary.json')
 if (OUT/'typeb_fault_review.json').exists():summary['typeb_fault_review']=read(OUT/'typeb_fault_review.json')
 save(OUT/'summary.json',summary)
 with (OUT/'comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 def pct(v):return '\u2014' if v is None else f'{100*v:.2f}%'
 body=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>TypeA / TypeB 补充测试比较</title><style>body{font-family:system-ui,sans-serif;margin:36px;max-width:1250px;color:#18202a}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#f0f3f7}.better{background:#eaf7ef}.baseline{font-weight:bold}p{line-height:1.7}code{background:#eee;padding:2px 5px}</style><h1>TypeA / TypeB 未保留候选：补充测试比较</h1>',
 '<p>候选名单在查看本次候选测试结果前固定：选取已完成、未被采纳，且验证集 F1 或交叉验证 F1 高于 trial_001 的版本。TypeA 共 10 个、TypeB 共 9 个。每个候选复用原模型、原验证阈值和原特征程序，不重新训练、不调整阈值、不调用模型 API。基线复用此前已核验的测试结果。</p>',
 '<p>测试区间：北京时间 2024-05-01 14:24 至 2024-06-01 00:00（右端不含）。指标为固定提前预警窗口下的设备级 F1：故障设备若只有窗口外警报，同时记误报和漏报；随访不明确的设备排除并单独记录。TypeA 可评估故障设备 101 台，TypeB 12 台。</p>',
 '<p>这一时间段历史上已经测试过，因此本表是补充比较，不是新的独立盲测。表内最高分只能描述这些候选在该时间段的表现；原搜索状态与 best=trial_001 保持不变。</p>']
 for label,s in summary['tasks'].items():
  best=s['highest_observed_test_result'];body.append(f'<h2>{label.upper()}</h2><p>{s["improved_candidates"]} / {s["tested_candidates"]} 个候选的测试 F1 高于基线。最高观察值：<code>{best["trial"]}</code>，F1 {pct(best["test_f1"])}。</p>')
  body.append('<table><tr><th>版本</th><th>验证 F1</th><th>CV F1</th><th>测试 F1</th><th>较基线（百分点）</th><th>精确率</th><th>召回率</th><th>TP</th><th>FP</th><th>FN</th><th>新增命中 / 丢失命中</th></tr>')
  for x in [s['baseline']]+s['candidates']:
   cls='baseline' if x['trial']=='trial_001' else ('better' if x['delta_test_f1']>0 else '')
   body.append(f'<tr class="{cls}"><td>{x["trial"]}</td><td>{pct(x["validation_f1"])}</td><td>{pct(x["cv_f1"])}</td><td>{pct(x["test_f1"])}</td><td>{100*x["delta_test_f1"]:+.2f}</td><td>{pct(x["precision"])}</td><td>{pct(x["recall"])}</td><td>{x["TP"]}</td><td>{x["FP"]}</td><td>{x["FN"]}</td><td>{x["new_hits"]} / {x["lost_hits"]}</td></tr>')
  body.append('</table>')
  if best['trial']!='trial_001':
   accepted=next(t['acceptance'] for t in frozen['tasks'][label]['candidates'] if t['trial']==best['trial'])
   ci=accepted.get('cv_interval_95')
   if ci:
    body.append(f'<p>本次最高观察值 {best["trial"]} 当时未被采纳：CV F1 增益区间为 [{100*ci[0]:+.2f}, {100*ci[1]:+.2f}] 个百分点，包含零；CV 新增命中 {accepted.get("new_hits")} 台、丢失命中 {accepted.get("lost_hits")} 台。原自动采纳规则同时要求区间下界大于零，且新增命中不低于丢失命中。这些是当时的验证证据，与本次测试统计分开记录。</p>')
 if 'historical_typeb' in summary:
  body.append('<h2>TypeB 与修改前版本的同口径复测</h2><p>用户追问旧版表现后，追加复测旧包的 trial_001 和 trial_015。核验 7,175 份源特征文件哈希一致、66 列特征及顺序一致、测试时间段和故障记录一致。保留旧模型原阈值。旧评估只计入 1,908 台设备、6 台故障；当前评估计入 7,119 台设备、12 台故障。旧模型在原 1,908 台子集上复现了原报告的 TP / FP / FN / F1。</p>')
  body.append('<table><tr><th>模型</th><th>评估范围</th><th>F1</th><th>精确率</th><th>召回率</th><th>TP</th><th>FP</th><th>FN</th></tr>')
  for x in summary['historical_typeb']['comparisons']:
   scope='当前 7,119 台' if x['scope']=='current_full_cohort' else '原 1,908 台子集'
   body.append(f'<tr><td>{x["model"]}</td><td>{scope}</td><td>{pct(x["f1"])}</td><td>{pct(x["precision"])}</td><td>{pct(x["recall"])}</td><td>{x["TP"]}</td><td>{x["FP"]}</td><td>{x["FN"]}</td></tr>')
  body.append('</table><p>旧 trial_015 在当前相同评估范围上为 7.41%，高于本轮最高 5.56%；两者均命中 1 台故障，旧版误报 14 台、新版误报 23 台。原 20% 与当前成绩的差别既有统计范围变化，也有模型及其固定阈值组合的实际表现变化。当前证据不能将变化单独归因于某一项代码改动。</p><p><strong>TypeB 的实际结论是效果不足：旧版和本轮最好候选都只命中 12 台故障中的 1 台，召回率均为 8.33%。F1 的微小差别来自误报数量，不能表述为故障识别能力的有效提升。仅在这两个模型之间替换不能解决多数故障漏报的问题。</strong></p>')
 if 'typeb_fault_review' in summary:
  body.append('<p>TypeB 逐台故障诊断：新版基线、新版 trial_013 和旧版 trial_015 都有 10 台故障在有效提前预警窗口内得到过评分，但未达到各自冻结阈值；另 1 台在该窗口没有可用评分。不能把没有评分直接等同于完全没有原始数据，也不能据此在本测试段上重新调阈值。逐台记录见 typeb_fault_review.csv。</p>')
 body.append('<p>附件包含固定候选清单、逐设备测试预测、比较结果、原模型和特征程序。自动核对了模型与程序文件指纹、原搜索状态、相同设备群体，以及从逐设备记录重新计算的 TP / FP / FN / F1。没有修改最终提交选择。</p></html>')
 (OUT/'report.html').write_text('\n'.join(body),encoding='utf-8')
 archive=R/'memory_rejected_comparison_20261029.zip';entries={}
 def add(z,source,name):
  z.write(source,name);entries[name]=sha(source)
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in ['frozen.json','summary.json','comparison.csv','report.html','typeb_fault_review.csv','typeb_fault_review.json']:add(z,OUT/n,n)
  for n in ['compare_rejected_memory.py','package_rejected_memory.py','compare_historical_typeb.py','typeb_fault_review.py']:add(z,R/n,'scripts/'+n)
  add(z,R/'release.json','release.json')
  for label,e in frozen['tasks'].items():
   for n in ['config.json','state.json','mapping.json','code_seal.json']:add(z,Path(e['session'])/n,label+'/original_search/'+n)
   for n in e['program_files']:add(z,OUT/label/n,label+'/'+n)
   for n in ['report_test.json','devices_test.csv','input_audit.json','complete.json']:add(z,BASE/label/n,label+'/trial_001/'+n)
   for n in ['model.ubj','result.json']:add(z,Path(e['session'])/'trials/trial_001/attempt_01'/n,label+'/trial_001/original_'+n)
   for t in e['candidates']:
    for n in ['report_test.json','devices_test.csv','input_audit.json','complete.json']:add(z,OUT/label/t['trial']/n,label+'/'+t['trial']+'/'+n)
    for n in ['model.ubj','result.json','complete.json']:add(z,Path(t['folder'])/n,label+'/'+t['trial']+'/original_'+n)
  if historical.exists():
   for p in sorted(historical.rglob('*')):
    if p.is_file():add(z,p,'historical_typeb/'+str(p.relative_to(historical)))
  z.writestr('SHA256_MANIFEST.json',json.dumps(entries,indent=2))
 save(OUT/'delivery.json',dict(archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),files=len(entries),verified=True))
 print(json.dumps(summary));print(json.dumps(read(OUT/'delivery.json')))

if __name__=='__main__':main()
